#!/usr/bin/env bash

cargo fmt --all --check

