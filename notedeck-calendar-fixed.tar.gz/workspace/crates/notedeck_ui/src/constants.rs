/// Default frame margin
pub const FRAME_MARGIN: i8 = 8;
