<!--
SPDX-FileCopyrightText: 2022 Kamila Borowska <kamila@borowska.pw>

SPDX-License-Identifier: MIT OR Apache-2.0
-->

# enum-map-derive

This is a derive macro for `enum-map`. You don't need to specify it
in dependencies as `enum-map` crate re-exports it.
