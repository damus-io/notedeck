#![allow(non_upper_case_globals)]
use objc2::ffi::NSUInteger;

pub const MTLCounterErrorValue: u64 = !0;
pub const MTLCounterDontSample: NSUInteger = (-1isize) as NSUInteger;
