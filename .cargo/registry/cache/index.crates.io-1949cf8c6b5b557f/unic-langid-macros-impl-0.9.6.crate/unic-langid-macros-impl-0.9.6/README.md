This is an internal macro implementation crate for `unic-langid`. Please use `unic-langid`.
