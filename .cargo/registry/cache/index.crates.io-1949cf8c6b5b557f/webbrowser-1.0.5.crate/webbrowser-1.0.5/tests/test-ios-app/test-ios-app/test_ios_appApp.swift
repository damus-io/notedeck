//
//  test_ios_appApp.swift
//  test-ios-app
//
//  Created by Amod Malviya on 05/09/22.
//

import SwiftUI

@main
struct test_ios_appApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
