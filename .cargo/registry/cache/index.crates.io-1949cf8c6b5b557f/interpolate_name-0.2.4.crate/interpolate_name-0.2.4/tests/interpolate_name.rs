use interpolate_name::interpolate_name;


#[allow(unnameable_test_items)]
#[interpolate_name(1)]
#[test]
fn t() {

}


