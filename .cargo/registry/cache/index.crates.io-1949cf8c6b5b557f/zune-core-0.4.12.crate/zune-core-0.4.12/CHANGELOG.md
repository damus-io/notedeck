## 0.2.14

- Fixed building with no-std
- Add `peek_at` and `pos` for writer
- Make serde non default
- Add option to make PNG add an alpha channel

## 0.2.12

- Add endianness conversion
- Hide exposed values for EncoderOptions
- Add Float32 bit depth
- Remove support for BitDepth 10 and 12
- Add bit_size method

## 0.2.1

Improve documentation on various parts

## 0.2.0

Initial version