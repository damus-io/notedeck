# 0.1.2 - 2024-05-14

- Fix bug in output of `InvalidError` [#88](https://github.com/rust-bitcoin/hex-conservative/pull/88).

# 0.1.1 - 2023-07-19

- [Add `test_hex_unwrap`](https://github.com/rust-bitcoin/hex-conservative/pull/24) hex parsing macro for test usage.
- [Improve formatting](https://github.com/rust-bitcoin/hex-conservative/pull/25) hex for bytes slices e.g., support padding.

# 0.1.0 - 2023-06-20 Initial Release

- [Import](https://github.com/rust-bitcoin/hex-conservative/pull/1) code from the `bitcoin_hashes` and `bitcoin-internals` crates.
- [Add `Iterator` implementations](https://github.com/rust-bitcoin/hex-conservative/pull/9)
