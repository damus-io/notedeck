Rust Bitcoin Internals
======================

This crate is only meant to be used internally by crates in the
[rust-bitcoin](https://github.com/rust-bitcoin) ecosystem.

This crate will never be stabilized, depend on it at your own risk.
