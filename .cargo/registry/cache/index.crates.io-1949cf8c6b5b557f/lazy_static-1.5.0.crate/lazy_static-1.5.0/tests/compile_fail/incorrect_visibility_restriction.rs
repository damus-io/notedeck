#[macro_use]
extern crate lazy_static;

lazy_static! {
    pub(nonsense) static ref WRONG: () = ();
}

fn main() { }
