#[macro_use]
extern crate lazy_static;

lazy_static! {
    pub static ref FOO: str = panic!();
}


fn main() { }
