# List of framework crates

The following is a full list of currently supported framework crates.

See [#393] if the framework that you need is not here. Note that a lot of
frameworks are CoreFoundation-like, those are more difficult to support, see
[#556] for more information.

[#393]: https://github.com/madsmtm/objc2/issues/393
[#556]: https://github.com/madsmtm/objc2/issues/556

<!-- list_data.md is included here in the final docs -->
