# rust-utf8

Incremental, zero-copy UTF-8 decoding for Rust

[Documentation](https://docs.rs/utf-8/)
