## Version 0.1.1

- Use `Infallible` instead of `Result<T, ()>`
- Always inline passthrough methods to guarantee zero overhead
