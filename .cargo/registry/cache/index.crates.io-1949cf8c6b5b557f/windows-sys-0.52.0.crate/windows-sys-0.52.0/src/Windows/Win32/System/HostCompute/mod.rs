pub type HCS_CALLBACK = isize;
