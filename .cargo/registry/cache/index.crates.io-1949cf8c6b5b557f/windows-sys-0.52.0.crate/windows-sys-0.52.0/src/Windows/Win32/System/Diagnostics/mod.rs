#[cfg(feature = "Win32_System_Diagnostics_Ceip")]
#[doc = "Required features: `\"Win32_System_Diagnostics_Ceip\"`"]
pub mod Ceip;
#[cfg(feature = "Win32_System_Diagnostics_Debug")]
#[doc = "Required features: `\"Win32_System_Diagnostics_Debug\"`"]
pub mod Debug;
#[cfg(feature = "Win32_System_Diagnostics_Etw")]
#[doc = "Required features: `\"Win32_System_Diagnostics_Etw\"`"]
pub mod Etw;
#[cfg(feature = "Win32_System_Diagnostics_ProcessSnapshotting")]
#[doc = "Required features: `\"Win32_System_Diagnostics_ProcessSnapshotting\"`"]
pub mod ProcessSnapshotting;
#[cfg(feature = "Win32_System_Diagnostics_ToolHelp")]
#[doc = "Required features: `\"Win32_System_Diagnostics_ToolHelp\"`"]
pub mod ToolHelp;
