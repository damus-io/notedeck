#[cfg(feature = "Win32_Management_MobileDeviceManagementRegistration")]
#[doc = "Required features: `\"Win32_Management_MobileDeviceManagementRegistration\"`"]
pub mod MobileDeviceManagementRegistration;
