#[cfg(feature = "Wdk")]
#[doc = "Required features: `\"Wdk\"`"]
pub mod Wdk;
#[cfg(feature = "Win32")]
#[doc = "Required features: `\"Win32\"`"]
pub mod Win32;
