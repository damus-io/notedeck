#[cfg(feature = "Win32_Security_Authentication_Identity")]
#[doc = "Required features: `\"Win32_Security_Authentication_Identity\"`"]
pub mod Identity;
