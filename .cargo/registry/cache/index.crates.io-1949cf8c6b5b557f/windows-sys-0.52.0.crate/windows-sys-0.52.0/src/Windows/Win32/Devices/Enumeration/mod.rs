#[cfg(feature = "Win32_Devices_Enumeration_Pnp")]
#[doc = "Required features: `\"Win32_Devices_Enumeration_Pnp\"`"]
pub mod Pnp;
