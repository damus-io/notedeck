#[cfg(feature = "Win32_Data_HtmlHelp")]
#[doc = "Required features: `\"Win32_Data_HtmlHelp\"`"]
pub mod HtmlHelp;
#[cfg(feature = "Win32_Data_RightsManagement")]
#[doc = "Required features: `\"Win32_Data_RightsManagement\"`"]
pub mod RightsManagement;
