#[cfg(feature = "Win32_Storage_Packaging_Appx")]
#[doc = "Required features: `\"Win32_Storage_Packaging_Appx\"`"]
pub mod Appx;
