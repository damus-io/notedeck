// The following two definitions should yield the same list of tokens.
// If https://bugs.llvm.org//show_bug.cgi?id=9069 is not fixed, they don't.
#define A 1
#define A 1
