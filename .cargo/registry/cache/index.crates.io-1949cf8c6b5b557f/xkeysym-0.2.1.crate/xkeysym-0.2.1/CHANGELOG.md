# v0.2.1

- Add new keysyms from xorgproto 2024.1. (#29)
- Add Keysym::NoSymbol. This is an alias for the "NO_SYMBOL" constant. (#17)
