# xcursor-rs

[![Crates.io](https://img.shields.io/crates/v/xcursor)](https://crates.io/crates/xcursor)
[![Docs.rs](https://docs.rs/xcursor/badge.svg)](https://docs.rs/xcursor/)
[![LICENSE](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

A library to load XCursor themes, and parse XCursor files.

# MSRV

The minimum supported Rust version is 1.34.0