# jni-sys-macros

Internal proc macros for the [jni-sys](https://crates.io/crates/jni-sys) crate.
