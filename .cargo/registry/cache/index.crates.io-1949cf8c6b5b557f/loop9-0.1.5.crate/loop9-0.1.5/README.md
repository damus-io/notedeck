# 9 neighboring pixels iterator

Tiny helper function to visit every pixel in the image together with its neighboring pixels. Duplicates pixels on the edges.

Ideal for implementing small image convolutions like blur, sharpening or edge detection.
