This is an internal macro declaration crate for `unic-langid`. Please use `unic-langid` instead.
