The test data comes from
https://www.unicode.org/Public/UCD/latest/ucd/NormalizationTest.txt
