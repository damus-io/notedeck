windows_targets::link!("kernel32.dll" "system" fn CeipIsOptedIn() -> windows_sys::core::BOOL);
