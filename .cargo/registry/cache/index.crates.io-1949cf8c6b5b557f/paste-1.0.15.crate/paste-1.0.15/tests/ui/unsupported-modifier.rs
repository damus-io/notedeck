use paste::paste;

paste! {
    fn [<a:pillow>]() {}
}

fn main() {}
