use paste::paste;

paste! {
    fn [<env!()>]() {}
}

fn main() {}
