use paste::paste;

paste! {
    fn [<name:0>]() {}
}

fn main() {}
