[![Build Status](https://travis-ci.org/miklelappo/android-properties.svg?branch=master)](https://travis-ci.org/miklelappo/android-properties)
[![crates.io](https://img.shields.io/crates/v/android-properties.svg)](https://crates.io/crates/android-properties)
[![License](https://img.shields.io/github/license/miklelappo/android-properties.svg)](https://github.com/miklelappo/android-properties/blob/master/LICENSE)

Rust-based Android properties wrapper
=====================================
