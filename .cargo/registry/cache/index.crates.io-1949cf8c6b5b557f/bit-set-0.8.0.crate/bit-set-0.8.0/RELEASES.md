Version 0.7.0 (not yet released) (ZERO BREAKING CHANGES)
========================================================

<a id="v0.7.0"></a>

- `serde::Serialize`, `Deserialize` is derived under the `serde` optional feature
- `impl Display` is implemented
- `impl Debug` has different output (we do not promise stable `Debug` output)
- `fn truncate` is implemented
- `fn get_mut` is implemented
