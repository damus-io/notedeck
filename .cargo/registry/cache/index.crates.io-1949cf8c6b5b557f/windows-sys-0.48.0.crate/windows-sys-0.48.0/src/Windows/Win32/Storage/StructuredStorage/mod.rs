pub type JET_API_PTR = usize;
pub type JET_HANDLE = usize;
pub type JET_INSTANCE = usize;
pub type JET_SESID = usize;
pub type JET_TABLEID = usize;
