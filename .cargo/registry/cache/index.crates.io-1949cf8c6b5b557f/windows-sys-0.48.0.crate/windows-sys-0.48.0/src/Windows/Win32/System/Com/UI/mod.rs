pub type IDummyHICONIncluder = *mut ::core::ffi::c_void;
pub type IThumbnailExtractor = *mut ::core::ffi::c_void;
