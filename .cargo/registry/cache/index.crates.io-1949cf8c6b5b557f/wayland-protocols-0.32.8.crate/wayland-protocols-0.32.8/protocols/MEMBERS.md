# wayland-protocols members

- GTK/Mutter: Jonas Ådahl <jadahl@gmail.com> (@jadahl),
  Carlos Garnacho <carlosg@gnome.org> (@carlosg)
- KWin: Vlad Zahorodnii <vlad.zahorodnii@kde.org> (@zzag),
  David Edmundson <david@davidedmundson.co.uk> (@davidedmundson),
  Xaver Hugl <xaver.hugl@kde.org> (@Zamundaaa)
- mesa: Daniel Stone <daniel@fooishbar.org> (@daniels),
  Mike Blumenkrantz <michael.blumenkrantz@gmail.com> (@zmike)
- Mir: Christopher James Halse Rogers <raof@ubuntu.com> (@RAOF),
  Alan Griffiths <alan.griffiths@canonical.com>
- Qt: Eskil Abrahamsen Blomfeldt <eskil.abrahamsen-blomfeldt@qt.io>
  (@eskilblomfeldt)
- Smithay/Cosmic: Victoria Brekenfeld <wayland@drakulix.de> (@drakulix)
- Weston: Pekka Paalanen <pekka.paalanen@collabora.com> (@pq),
  Derek Foreman <derek.foreman@collabora.com> (@derekf)
- wlroots/Sway: Simon Ser <contact@emersion.fr> (@emersion),
  Simon Zeni <simon@bl4ckb0ne.ca> (@bl4ckb0ne)
- Chromium: Fangzhou Ge <fangzhoug@chromium.org> (@fangzhoug),
  Nick Yamane <nickdiego@igalia.com> (@nickdiego),
  Max Ihlenfeldt <max@igalia.com> (@mihlenfeldt)
