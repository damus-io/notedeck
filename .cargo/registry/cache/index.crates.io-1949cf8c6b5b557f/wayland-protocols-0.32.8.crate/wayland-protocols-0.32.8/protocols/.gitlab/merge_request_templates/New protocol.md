

#### Requirements for merging

- [ ] Review
- [ ] Implementations
- [ ] ACKs from members

/label ~"New Protocol" ~"In 30 day discussion period" ~"Needs acks" ~"Needs implementations" ~"Needs review"
