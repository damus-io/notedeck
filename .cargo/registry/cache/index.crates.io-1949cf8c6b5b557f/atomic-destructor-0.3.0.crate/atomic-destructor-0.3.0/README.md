# Atomic destructor

## License

This project is distributed under the MIT software license - see the [LICENSE](LICENSE) file for details
