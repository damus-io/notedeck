//! A cache of services

pub mod cache;
pub mod error;

pub use self::cache::ReadyCache;
