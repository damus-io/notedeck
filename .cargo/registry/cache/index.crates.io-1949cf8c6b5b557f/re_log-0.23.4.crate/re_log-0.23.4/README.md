# re_log

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_log.svg)](https://crates.io/crates/re_log)
[![Documentation](https://docs.rs/re_log/badge.svg)](https://docs.rs/re_log)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)

Helpers for setting up and doing text logging in the Rerun crates.
