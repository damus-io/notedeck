## window

Renders a spinning triangle to a [winit](https://github.com/rust-windowing/winit) window.

![Screenshot of the final render](./screenshot.png)

## To Run

```
cargo run --example window
```
