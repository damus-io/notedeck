//! # Arithmetic
//!
//! This parses arithmetic expressions and directly evaluates them.
//! ```rust
#![doc = include_str!("../../examples/arithmetic/parser.rs")]
//! ```
