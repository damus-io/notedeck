# Valuable

Valuable provides object-safe value inspection. Use cases include passing
structured data to trait objects and object-safe serialization.

## License

This project is licensed under the [MIT license](LICENSE).

### Contribution

Unless you explicitly state otherwise, any contribution intentionally submitted
for inclusion in Valuable by you, shall be licensed as MIT, without any additional
terms or conditions.