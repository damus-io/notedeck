# individual library tests

These tests should have the same name as the vcpkg port. They are intended to use to verify that building/linking/running is possible on each platform. 

The systests are intended to test that the current version of the vcpkg build helper will work with published versions of the most common -sys crates. 