use async_recursion::async_recursion;

#[async_recursion]
fn not_async() {}

fn main() {}