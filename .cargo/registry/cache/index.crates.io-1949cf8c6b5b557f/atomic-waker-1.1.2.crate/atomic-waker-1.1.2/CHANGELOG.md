# Version 1.1.2

- Add `smol-rs` logo to docs. (#16)

# Version 1.1.1

- Use `will_wake()` to avoid unnecessary cloning. (#12)

# Version 1.1.0

- Support `no_std` platforms. (#7)
- Support `portable-atomic` crate. (#7)

# Version 1.0.0

- Initial version
