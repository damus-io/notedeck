//! Code common to the front and backends for specific languages.

pub mod wgsl;
