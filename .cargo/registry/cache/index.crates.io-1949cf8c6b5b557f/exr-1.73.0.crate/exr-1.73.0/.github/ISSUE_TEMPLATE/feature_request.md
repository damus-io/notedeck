---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: 'enhancement'
assignees: ''

---

## What can be improved or is missing?
"Feature X is important for doing Y."

## Implementation Approach
If you have an idea, 
outline one or two approaches
how the feature could look on the surface.

