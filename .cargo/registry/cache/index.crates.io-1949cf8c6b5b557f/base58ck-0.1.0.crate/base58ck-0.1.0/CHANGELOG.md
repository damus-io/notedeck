# 0.1.0 - 2024-03-14

Initial release of the `base58ck` crate. This crate was cut out of
`rust-bitcoin` and cleaned up for release as a separate crate.
