// Same source, just compiled for 2018 edition
include!("newtype.rs");
