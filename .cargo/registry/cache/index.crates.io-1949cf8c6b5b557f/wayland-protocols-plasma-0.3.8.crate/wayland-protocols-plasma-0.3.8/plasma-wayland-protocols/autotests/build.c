// SPDX-License-Identifier: CC0-1.0

#include "@CLIENT_HEADER@"
#include "@SERVER_HEADER@"

int main()
{
    return 0;
}
