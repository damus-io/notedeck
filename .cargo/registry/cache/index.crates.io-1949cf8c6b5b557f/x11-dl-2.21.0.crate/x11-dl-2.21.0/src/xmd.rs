pub type INT8 = i8;
pub type INT16 = i16;
pub type INT32 = i32;
pub type INT64 = i64;

pub type CARD8 = u8;
pub type CARD16 = u16;
pub type CARD32 = u32;
pub type CARD64 = u64;

pub type BYTE = CARD8;
pub type BOOL = CARD8;
