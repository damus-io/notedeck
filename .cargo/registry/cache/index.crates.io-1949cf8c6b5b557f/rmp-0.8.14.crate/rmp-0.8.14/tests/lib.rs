#[cfg(test)]
#[macro_use]
extern crate quickcheck;

mod func {
    mod decode;
    mod encode;
    mod mirror;
}
