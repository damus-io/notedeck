Version 0.8.0 (2024-07-16)
==========================

<a id="v0.8.0"></a>

- `fn insert` is implemented
- `impl Display` is implemented
- `impl Debug` has different output
