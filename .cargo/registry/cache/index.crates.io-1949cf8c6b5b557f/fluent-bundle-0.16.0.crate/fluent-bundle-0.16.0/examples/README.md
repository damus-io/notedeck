This directory contains a set of examples
of how to use Fluent.

Start with the `simple-app.rs` which is a very
trivial example of a command line application
with localization handled by Fluent.
