# Async Utility

## Description

Collection of `async` utilities.

## WASM

This crate support WASM targets.

## License

This project is distributed under the MIT software license - see the [LICENSE](LICENSE) file for details
