windows_targets::link!("kernel32.dll" "system" fn CeipIsOptedIn() -> super::super::super::Foundation:: BOOL);
