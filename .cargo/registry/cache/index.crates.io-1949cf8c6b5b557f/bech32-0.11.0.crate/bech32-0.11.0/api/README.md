API text files
==============

Each file here lists the public API when built with some set of features
enabled. To create these files run `../contrib/check-for-api-changes.sh`:

Requires `cargo-public-api`, install with:

    `cargo +stable install cargo-public-api --locked`.

ref: https://github.com/enselic/cargo-public-api
