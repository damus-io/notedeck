#### Running the examples

The examples can be run as follows:

```sh
cargo run --package=icrate --example=basic_usage --features=unstable-example-basic_usage
cargo run --package=icrate --example=delegate --features=unstable-example-delegate
```
