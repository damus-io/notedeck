extern "C" {
    #[cfg(feature = "Foundation_NSMapTable")]
    pub fn NSFreeMapTable(table: *mut crate::Foundation::NSMapTable);
}

// TODO: Add `-[NSKeyedUnarchiverDelegate unarchiver:didDecodeObject:]`
