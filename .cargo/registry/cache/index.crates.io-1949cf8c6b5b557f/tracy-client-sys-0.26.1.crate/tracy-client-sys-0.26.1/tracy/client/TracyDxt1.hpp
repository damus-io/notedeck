#ifndef __TRACYDXT1_HPP__
#define __TRACYDXT1_HPP__

namespace tracy
{

void CompressImageDxt1( const char* src, char* dst, int w, int h );

}

#endif
