extern "C" {
    pub fn ___tracy_fiber_enter(fiber: *const ::std::os::raw::c_char);
}
extern "C" {
    pub fn ___tracy_fiber_leave();
}
