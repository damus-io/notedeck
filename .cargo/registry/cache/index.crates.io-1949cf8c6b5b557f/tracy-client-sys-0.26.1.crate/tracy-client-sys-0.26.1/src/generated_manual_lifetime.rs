extern "C" {
    pub fn ___tracy_startup_profiler();
}
extern "C" {
    pub fn ___tracy_shutdown_profiler();
}
