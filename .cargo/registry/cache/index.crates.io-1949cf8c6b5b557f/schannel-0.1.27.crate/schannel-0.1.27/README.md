schannel-rs [![.github/workflows/ci.yaml](https://github.com/steffengy/schannel-rs/actions/workflows/ci.yaml/badge.svg)](https://github.com/steffengy/schannel-rs/actions/workflows/ci.yaml)
=====

[Documentation](https://docs.rs/schannel/0/x86_64-pc-windows-msvc/schannel/)

Rust bindings to the Windows SChannel APIs providing TLS client and server functionality.
