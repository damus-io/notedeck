# Security Policy

## Reporting a Vulnerability

Please report security issues to `jb55@jb55.com`
